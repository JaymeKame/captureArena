// Minimal InZone Game SDK bridge. Every export here is safe to call whether
// or not the game is actually running inside the InZone app's WebView —
// outside InZone, `window.InZoneSDK` never appears, so each function
// becomes a harmless no-op instead of throwing. Never invents fallback
// values or waits with a timeout for the config; see
// docs/inzone-sdk-reference.md in the source repo for the full API this
// wraps.

export function isInzoneHost() {
  return typeof window !== "undefined" && !!window.InZoneSDK;
}

// Resolves with the InZone config object once it arrives (immediately if
// already injected, otherwise on the one-shot `inzone:sdk-ready` event).
// Never resolves at all outside InZone — only await this if the caller is
// fine waiting indefinitely (e.g. a one-time boot hook), never on a path
// the player is blocked on.
let _configPromise = null;
export function inzoneConfig() {
  if (_configPromise) return _configPromise;
  _configPromise = new Promise((resolve) => {
    if (window.__INZONE_SOCIAL_LOOP_CONFIG__) {
      resolve(window.__INZONE_SOCIAL_LOOP_CONFIG__);
      return;
    }
    window.addEventListener("inzone:sdk-ready", (e) => resolve(e.detail), { once: true });
  });
  return _configPromise;
}

export async function inzonePostScore(score, extra = {}) {
  if (!isInzoneHost()) return null;
  try {
    return await window.InZoneSDK.postScore({
      score,
      playerName: extra.playerName,
      durationMs: extra.durationMs,
      metadata: extra.metadata,
    });
  } catch (err) {
    console.warn("[inzone] postScore failed:", err);
    return null;
  }
}

// Creates a 24h duel and opens the native share sheet. `senderId` is
// required by the endpoint and the bridge does NOT fill it in, so the caller
// must pass the config's userId. Per the SDK reference the generated deep
// link opens the game on the Game Hub and does NOT carry a room code — any
// room the recipient should land in has to be spelled out in `message` and
// `shareUrl` by us.
export async function inzoneSendChallenge(payload) {
  if (!isInzoneHost()) return { ok: false, reason: "not-inzone" };
  try {
    const data = await window.InZoneSDK.sendChallenge(payload);
    return { ok: true, data };
  } catch (err) {
    return { ok: false, reason: err?.message || "challenge-failed", err };
  }
}

export async function inzoneGetCoinBalance() {
  if (!isInzoneHost()) return null;
  try {
    const data = await window.InZoneSDK.gameState({});
    return data?.data?.balance ?? null;
  } catch (err) {
    console.warn("[inzone] gameState failed:", err);
    return null;
  }
}

// tier must be one of 10, 50, 150, 400 per the InZone coin-tier contract.
export async function inzonePurchase(tier, title, description) {
  if (!isInzoneHost()) return { ok: false, reason: "not-inzone" };
  try {
    const data = await window.InZoneSDK.purchaseCoinTier(tier, { title, description });
    return { ok: true, data };
  } catch (err) {
    return { ok: false, reason: err?.message || "purchase-failed", err };
  }
}

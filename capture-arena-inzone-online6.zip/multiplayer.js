import * as Colyseus from "./vendor/colyseus.esm.js";

// The client can be loaded from all sorts of hosts that are NOT themselves
// the Colyseus server — itch.io's iframe sandbox, GitHub Pages, a CDN, or
// an app WebView (e.g. InZone) that just renders this bundle's index.html
// from some opaque internal origin. Hostname-sniffing for a fixed list of
// known hosts (the previous approach) silently breaks under any host that
// isn't on the list — which is exactly what happened here. Instead: always
// trust an explicit <meta name="game-remote-origin"> when present, since
// it's an explicit statement of where the server actually is; only fall
// back to same-origin when no meta tag is set at all.
//
// Source of the remote origin (in order):
//   1. <meta name="game-remote-origin" content="https://your-host.tld">
//      in index.html. Forks edit one line and they're done.
//   2. Same-origin fallback (location.host) — correct when this file is
//      served directly by the Colyseus server itself, and when no meta
//      tag is present at all.
const INPUT_BUFFER_MAX = 100; // ~3.3s @ 30Hz

function _readMetaOrigin() {
  const meta = document.querySelector('meta[name="game-remote-origin"]');
  const origin = meta?.getAttribute("content")?.trim();
  if (!origin) return null;
  // Convert https:// → wss:// (and http:// → ws://) so the origin can be
  // shared with the telemetry endpoint without rewriting per-call.
  return origin.replace(/^http(s?):\/\//i, (_m, s) => `ws${s ? "s" : ""}://`);
}

function _resolveServerUrl() {
  const metaOrigin = _readMetaOrigin();
  if (metaOrigin) return metaOrigin;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  return `${proto}://${location.host}`;
}

export class MultiplayerClient {
  constructor() {
    this.client = new Colyseus.Client(_resolveServerUrl());
    this.room = null;
    this.leaving = false;
    this.playerToken = null;

    // Set by the host before connecting. When true the server holds this
    // player's character down after each death until sendRespawnPaid() is
    // called, so the 10-coin charge actually gates the respawn instead of
    // just decorating it.
    this.paidRespawn = false;

    // Input sequence tracking for server-confirmed reconciliation.
    // Each input message is tagged with a monotonically increasing seq;
    // server echoes back the latest applied seq via CharacterSchema
    // .lastAppliedInputSeq. The client uses ackInputs() to drop confirmed
    // entries from the buffer; unacked inputs are replayed onto the
    // server-confirmed pos to derive the new predicted state.
    this.inputSeq = 0;
    this.inputBuffer = []; // [{ seq, dirX, dirZ, t }]

    // RTT tracking — last 5 samples in ms, median reported by getRTT().
    this._rttSamples = [];
    this._pingInterval = null;

    // Event hooks (set by host renderer)
    this.onState = null;           // (state) => void
    this.onClaim = null;           // (charId, factionId, trailPoints?, replayTrail) => void
    this.onClaimResult = null;     // (charId, factionId, cells:Int32Array) => void
    this.onHeal = null;            // (changedCells) => void
    this.onTrailVertex = null;     // (charId, x, z) => void
    this.onKill = null;            // (killerId, victimId) => void
    this.onTeleport = null;        // (charId, posX, posZ, dirX, dirZ, reason) => void
    this.onYourCharId = null;      // (charId) => void
    this.onGridSnapshot = null;    // (b64) => void
    this.onCumulativeScore = null; // (score) => void
    this.onNameRejected = null;    // ({reason}) => void — server says name conflict
    this.onDisconnected = null;    // (code) => void — room closed or socket dropped
  }

  async connect(playerName, playerToken) {
    let token = playerToken || localStorage.getItem("playerToken");
    if (!token) {
      token = crypto.randomUUID();
      localStorage.setItem("playerToken", token);
    }
    this.playerToken = token;

    this.room = await this.client.joinOrCreate("game", {});
    this._wireRoomHandlers();
    this.room.send("hello", { name: playerName, playerToken: token, paidRespawn: this.paidRespawn });
    return this.room;
  }

  // Join a private room by 6-char code. Same hello flow.
  async joinPrivate(code, playerName) {
    let token = localStorage.getItem("playerToken");
    if (!token) {
      token = crypto.randomUUID();
      localStorage.setItem("playerToken", token);
    }
    this.playerToken = token;

    this.room = await this.client.join("private", { code });
    this._wireRoomHandlers();
    this.room.send("hello", { name: playerName, playerToken: token, paidRespawn: this.paidRespawn });
    return this.room;
  }

  // Create a private room with the given config + immediately join it.
  async createPrivate(config, playerName) {
    let token = localStorage.getItem("playerToken");
    if (!token) {
      token = crypto.randomUUID();
      localStorage.setItem("playerToken", token);
    }
    this.playerToken = token;

    this.room = await this.client.create("private", config);
    this._wireRoomHandlers();
    this.room.send("hello", { name: playerName, playerToken: token, paidRespawn: this.paidRespawn });
    return this.room;
  }

  _wireRoomHandlers() {
    // Diagnostic: track gap between consecutive state-change deliveries.
    // Expected cadence is 33ms (server patchRate = TICK_MS). Anything > 80ms
    // means the server tick stalled, the network buffered, or the client
    // event loop was blocked. The 500ms upper bound filters tab-backgrounding.
    let _lastStateChangeTs = 0;
    this.room.onStateChange((state) => {
      const now = performance.now();
      if (_lastStateChangeTs > 0) {
        const gap = now - _lastStateChangeTs;
        if (gap > 80 && gap < 500) {
          console.log(`[patch gap] ${gap.toFixed(0)}ms`);
        }
      }
      _lastStateChangeTs = now;
      this.onState?.(state);
    });

    const handlers = [
      ["claim",           "onClaim",           (m) => [m.charId, m.factionId, m.trailPoints, !!m.replayTrail]],
      ["claimResult",     "onClaimResult",     (m) => [m.charId, m.factionId, m.cells]],
      ["heal",            "onHeal",            (m) => [m.changedCells]],
      ["trailVertex",     "onTrailVertex",     (m) => [m.charId, m.x, m.z]],
      ["kill",            "onKill",            (m) => [m.killerId, m.victimId]],
      ["teleport",        "onTeleport",        (m) => [m.charId, m.posX, m.posZ, m.dirX, m.dirZ, m.reason]],
      ["yourCharId",      "onYourCharId",      (m) => [m.charId]],
      ["gridSnapshot",    "onGridSnapshot",    (m) => [m.bytes]],
      ["cumulativeScore", "onCumulativeScore", (m) => [m.score]],
      ["nameRejected",    "onNameRejected",    (m) => [{ reason: m.reason }]],
    ];
    for (const [msg, hook, mapArgs] of handlers) {
      this.room.onMessage(msg, (payload) => {
        const fn = this[hook];
        if (fn) fn(...mapArgs(payload));
      });
    }
    this.room.onMessage("pong", (t) => {
      const rtt = performance.now() - t;
      this._rttSamples.push(rtt);
      while (this._rttSamples.length > 5) this._rttSamples.shift();
    });
    this._pingInterval = setInterval(() => {
      try { this.room?.send("ping", performance.now()); } catch {}
    }, 2000);

    // A dropped socket or a closed room used to leave the client rendering a
    // frozen arena that still looked live. Stop the ping timer, drop the room
    // reference, and let the host decide what to show.
    this.room.onLeave((code) => {
      if (this._pingInterval) { clearInterval(this._pingInterval); this._pingInterval = null; }
      const wasOurs = this.leaving;
      this.room = null;
      if (!wasOurs) this.onDisconnected?.(code);
    });
    this.room.onError((code, message) => {
      console.warn("[online] room error", code, message);
    });
  }

  sendInput(dirX, dirZ) {
    if (!this.room) return;
    this.inputSeq++;
    this.inputBuffer.push({
      seq: this.inputSeq,
      dirX,
      dirZ,
      t: performance.now(),
    });
    // Bound the buffer — at 30Hz this caps memory at ~3.3s of pending inputs.
    while (this.inputBuffer.length > INPUT_BUFFER_MAX) this.inputBuffer.shift();
    this.room.send("input", { dirX, dirZ, seq: this.inputSeq });
  }

  // Tell the server the 10-coin respawn purchase went through, releasing the
  // hold placed on this character when it died.
  sendRespawnPaid() {
    if (!this.room) return;
    this.room.send("respawnPaid", {});
  }

  // Drop inputs the server has already applied. Called by the client after
  // reading the local player's CharacterSchema.lastAppliedInputSeq.
  ackInputs(upToSeq) {
    while (this.inputBuffer.length > 0 && this.inputBuffer[0].seq <= upToSeq) {
      this.inputBuffer.shift();
    }
  }

  // Returns the median of the last 5 RTT samples in milliseconds, or null
  // if no pong has been received yet. Resistant to single-frame stalls.
  getRTT() {
    if (this._rttSamples.length === 0) return null;
    const sorted = [...this._rttSamples].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length / 2)];
  }

  disconnect() {
    // Marks the leave as ours so onLeave doesn't report it to the player as
    // a lost connection.
    this.leaving = true;
    if (this._pingInterval) { clearInterval(this._pingInterval); this._pingInterval = null; }
    if (this.room) this.room.leave();
  }
}
